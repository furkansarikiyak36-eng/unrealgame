FAZ 1 - Kütük çekirdeği (MyProject2)

Kurulum:
1. Source/MyProject2/Wood/ klasörünü projenin Source/MyProject2/ altına kopyala.
2. MyProject2.Build.cs içinde Core, CoreUObject, Engine bağımlılıkları yeterli (ek bağımlılık yok).
3. Editör kapalıyken .uproject -> Generate Visual Studio project files, sonra derle.

Kullanım:
- UWoodPieceComponent: kütük aktörüne ekle (ör. CarvableLog Blueprint'i). Kök primitive'i yönetir.
- UWoodCarrierComponent: oyuncu karakterine ekle; SetCarryAttachComponent ile omuz/mesh ver.
- Durumlar: Loose / Carried / Installed. Install() ve Uninstall() Faz 4-5'te yapı sistemi tarafından kullanılacak.

Kapsanan mekanikler: 4, 5, 6, 7, 8, 9, 10, 11 (hacim kapasitesi), 56 (sökme için Uninstall), 74 (fırlatma temeli).
Not: Dinamik mesh bileşeninde fizik simülasyonu için basit çarpışma gerekir; CarvableLog zaten bunu yapıyorsa ek işlem yok.
