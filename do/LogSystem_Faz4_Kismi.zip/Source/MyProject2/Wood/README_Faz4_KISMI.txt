FAZ 4 - KISMI PAKET (yarım kaldı, token nedeniyle durduruldu)

Bu zip Wood/ klasörünün TAMAMINI içerir (Faz 1+2+3 + Faz 4'ün bitmiş kısmı). Üzerine yaz.

BİTMİŞ (mantık mock ortamda test edildi, Faz 3'ün 38 kontrolü hâlâ geçiyor; UE'de DERLENMEDİ):
- Mekanik 61-63 mantığı (WoodStructureLogic):
  * FNode.Damage, JointLooseDamage=0.6, FailureDamage=0.85 sabitleri
  * Hasar >= 0.6: çentik/uç bağlantıları gevşer, o eklem destek aktarmaz (yaslanan tahta etkilenmez)
  * Hasar >= 0.85: parça kopar, hiç destekli sayılmaz
  * AccumulateDamage(Current, Amount)
- Mekanik 52 mantığı: FindTemporaryRemovalDependents (geçici parçalar sökülürse kalıcı hangi parça düşer)
- FNode.bTemporary ve UWoodPieceComponent::bTemporary (geçici iskele işareti)
- WoodStructureSubsystem::MakeNode artık Damage ve bTemporary aktarıyor
- WoodStructureTypes.h: EWoodFeatureKind ve FWoodFeature (yapı tanıma sonuç tipleri)
- WoodStructureGeometry.h: ortak geometri yardımcıları (Logic.cpp bunu kullanıyor)

YARIM / YAZILMADI:
- WoodStructureAnalysis.h SADECE BİLDİRİM. WoodStructureAnalysis.cpp YOK: AnalyzeStructure henüz tanımsız,
  hiçbir yerden çağrılmıyor (bu yüzden derlemeyi bozmaz). Planlanan: duvar (39-41), açıklık/kasa (42-44),
  platform (37), çatı (45-46), rampa/merdiven (47), köprü (48), korkuluk (50), iskele (49), savunma duvarı (51).
- Subsystem'e eklenecekler (yazılmadı): ApplyDamage, RepairPiece, ReplacePiece, RemoveTemporaryPieces,
  AnalyzeStructure, ApplyFireDamage. Hasar mantığı Logic katmanında hazır ama dünyaya bağlı değil.
- Hasar/geçici parça için yeni otomasyon testi yazılmadı.

Sıradaki adım: WoodStructureAnalysis.cpp + subsystem fonksiyonları + testler.
