FAZ 3 - Yapı alt sistemi (mekanik 12, 33-38, 53-58, 59'un ilk hâli)

Bu zip Wood/ klasörünün TAMAMINI içerir (Faz 1 + 2 + 3). Üzerine yaz.

Yeni dosyalar:
- WoodStructureTypes.h      : EWoodOrientation, EWoodConnectionKind, FWoodSnapResult (UHT: WoodStructureTypes.generated.h)
- WoodStructureLogic.h/.cpp : saf mantık (yön, rol, bağlantı, destek, söküm bağımlıları, snap). UObject yok.
- WoodStructureSubsystem.h/.cpp : dünya alt sistemi (Game/PIE). Zemin izi, kurulum, söküm, olaylar.
- WoodStructureTests.cpp    : otomasyon testleri. Editör: Session Frontend > Automation > MyProject2.Wood.Structure

Kurulum:
1. Wood/ klasörünü Source/MyProject2/Wood/ üzerine kopyala.
2. Build.cs: ek bağımlılık yok (Core, CoreUObject, Engine yeterli).
3. .uproject -> Generate project files, derle. Hata çıkarsa metni yapıştır.
4. Editörde Tools > Session Frontend > Automation > "MyProject2.Wood.Structure" testlerini çalıştır.

Kurallar (WoodStructureLogic):
- Yön: eksen dikeye/yataya 15 dereceden yakınsa dikey/yatay, değilse çapraz.
- Rol: yuvarlak dikey=direk (sivri uç=kazık), yatay=kiriş, çapraz=payanda. Tahta ve yarım kütük: yatay=döşeme, dikey=duvar, çapraz=çatı.
- Bağlantı: uç-uç (8 cm), uç-gövde, çentikli çaprazlama (çentik temas noktasının modül çizgisinde olmalı), tahta yaslanması.
  Sadece yan yana durmak bağlantı değildir (paralel parçalar bağlanmaz).
- Yön: diğer ucu daha yüksek olan parça üstte oturur (taşınan). Aynı yükseklikte uç uca = çift yönlü.
- Destek: zemindeki parça destekli. Kiriş/döşeme/çatı en az 2 destekli taşıyıcı ister, diğerleri 1. Döngüsel destek geçersiz.
- Snap: uç-uç öncelikli, uç-gövde hedefin modül çizgisine oturur (390 cm kütük, 65 cm modül).

Doğrulama: mantık katmanı UE'siz bir mock ortamda gerçek test dosyasıyla çalıştırıldı (38 kontrol geçti).
UObject/subsystem katmanı (zemin izi, Install/Uninstall, olaylar) UE'de DERLENMEDİ ve çalıştırılmadı.

Değişiklik (subsystem): FindSnap artık PruneInvalid çağırmaz (hayalet önizlemede olay yaymasın);
CollectNodes yok olmuş parçaları atlar.

BİLİNEN SINIRLAR:
- Eski StructuralIntegritySubsystem / LogConstructionActor ile entegrasyon yok; iki sistem ayrı çalışır.
- Çöküşte (bCollapseUnsupported) her parça için destek grafiği yeniden hesaplanır (büyük yapıda yavaş).
- Zemin izi sadece ECC_WorldStatic kanalına bakar.
- Pivot uzunluğun ortasında varsayılır; Faz 2 kesim çıktılarında bu henüz oyun içinde doğrulanmadı.
- Duvar (39-41), kapı/pencere (42-44), çatı (45-46), merdiven, köprü, iskele ayrı kurallar değil; Faz 4'te bu temel üstüne eklenecek.
