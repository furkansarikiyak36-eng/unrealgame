# MyProject2 World State Simulation — Teknik Denetim

## Paket kapsamı

- `WorldCore`: 6 header / 5 cpp (WorldTypes header-only; toplam 11 dosya)
- `WorldPhaseW1_Chunk`: 4 header / 4 cpp
- `WorldPhaseW2_Lazy`: 5 header / 5 cpp
- `WorldPhaseW3_Event`: 5 header / 5 cpp
- `WorldPhaseW4_WaterSoil`: 5 header / 5 cpp
- `WorldPhaseW5_FireDecayChem`: 5 header / 5 cpp
- `WorldPhaseW6_Persistence`: 3 header / 3 cpp
- Toplam: **33 header + 32 cpp = 65 kaynak dosyası**; 30 `UCLASS` tanımı ve bir `UINTERFACE` tanımı.

## Düzeltilen yüksek riskli noktalar

1. Blueprint UFUNCTION imzasından `FChunkCell*` gibi struct pointer dönüşleri çıkarıldı. Blueprint için `ReadCell`/`WriteCell`, native C++ tarafı için pointer erişimi var.
2. `FSerializedCell`, `FSerializedChunk` öncesinde tanımlandı; serialized data alanları açıkça archive'a yazılıyor. USTRUCT verisinin varsayılan bir `operator<<` varmış gibi doğrudan serialize edilmesi önlendi.
3. Load sırasında chunk/cell sayıları, hücre indeksleri, eksen uzunluğu, sürüm, dosya boyutu ve temel sayısal alanlar sınır kontrolünden geçiyor. Tüm payload sonu ve yinelenen chunk koordinatları kontrol edilmeden mevcut store değiştirilmez.
4. Deserialize sonrası chunk nesneleri `UChunkStateStore::AddOrReplaceChunk` üzerinden geri ekleniyor; önceki örnekteki store'a geri kaydetmeme hatası giderildi.
5. Save zarfına `magic + version + compression flag + raw/stored length` eklendi; temel World State paketinde v3, Material M6 entegrasyonlu birleşik pakette v4 yazılır ve v3 load uyumluluğu korunur. Sıkıştırma açıksa yalnızca sıkışmış veri daha küçükse Zlib kullanılıyor.
6. Dünya zamanı ve sıcaklık/min-max sıcaklık/yağış/rüzgâr/yağmur-kar flag/seed kayıt içine ekleniyor. Yükleme, `USimulationSubsystem` saati ve birikimli tick sayaçlarıyla senkronize ediliyor.
7. `UWorldStateSubsystem` fiziksel sistem güncellemelerini her karede bütün store'a uygulamak yerine yüklenmiş chunk'lar üzerinden bütçeli işler. Continuous her tick'e aday; Scheduled yaklaşık 5 saniyede bir; Passive, yeniden etkinleşince catch-up alır.
8. Chunk hücre indeksi sınırları doğrulanıyor; 64-bit sparse-cell anahtarı `Y*10000+X` çakışmasını kaldırıyor.
9. Yangın ve kimya komşu indekslemesinde satırın başından/sonuna taşma önlendi. Yangın yayılımı `FRand()` yerine chunk/hücre/gün tabanlı `FRandomStream` kullanıyor.
10. Su akış solver'ı artık `WaterSimulation` tarafından yerel chunk hücrelerine bağlanıyor; hücre hacmi transferleri aynı solver geçişinde çift yönlü anlık güncelleme yerine delta biriktirerek uygulanıyor.
11. T1 `SimulationSubsystem` içinde `TimeOfDay` gerçek-zaman ilerleme çarpanı düzeltildi: `DeltaTime / SecondsPerHour`; önceki `HoursPerDay / SecondsPerHour` formülü gündüz/gece döngüsünü günlük takvimle uyumsuz hızlandırıyordu.
12. 40 km² alan hesabı düzeltildi: `99 × 99 × 64² = 40.144896 km²`; `200 × 200` ayarı 40 km² değildir.

## Statik doğrulama

`Scripts/check_worldstate_source.py` şu an kaynak ağacında çalıştırılabilir. Kontroller: W1–W6 dosya sayısı, her UE header'da `.generated.h` include sırası, yerel include karşılıkları, `Build.cs` klasörleri, parantez dengesi ve alan hesabı. Bunlar sadece statik kaynak denetimidir.

**UE 5.8 derlemesi yapılmadı.** Çalışma ortamında UnrealBuildTool/Unreal Engine 5.8 bulunmuyor. Bu yüzden paket için "derlendi", "UHT geçti" veya "PIE test edildi" denemez.

## Bilinen sınırlamalar ve entegrasyon işleri

- **Görsel/world streaming yok:** Chunk state depolanır; gerçek render mesh, foliage, actor pooling, World Partition veya level streaming kurulumu yoktur.
- **Hidrolik model basitleştirilmiş:** Su akışı chunk içindeki 2D komşular arasında akar; terrain yükseklik farkı, kanal ağı, chunk sınırı aktarımı, yeraltı suyu ve doğrulanmış birim kalibrasyonu tamamlanmamıştır. Seviye `m³ / hücre alanı` yaklaşımıyla temsil edilir.
- **Hava geçmişi kısmi:** Pasif chunk yağış toplamı seed + gün numarası ile deterministik yeniden kurulur; mevcut günün hava değeri live kaynaktan gelir. Geçmiş sıcaklık/rüzgâr dizisi saklanmadığı ve kar örtüsü bulunmadığı için uzun catch-up meteorolojik açıdan birebir değildir. Kar şimdilik sıvı su eşdeğeri olarak uygulanır.
- **Event chain tam otomatik değil:** Bus ve responder interface mevcuttur, bazı su/yangın sistemleri olay yollar; ancak tüm sistemlerin otomatik kayıt olması veya su→toprak→bitki→raid zincirinin data-driven otomatik kurulması için adaptor/responder Blueprint/C++ kodu gerekir.
- **Önceki sistemlerin Actor verileri:** Tarım ve hayvancılık actor/component state'i, inventory içeriği ve Raid Director durumları bu chunk kaydına otomatik dahil edilmez. Bir kayıt manifesti ve `ISaveGame`/snapshot köprüleriyle ayrıca bağlanmalıdır.
- **Simulation budget kesin zaman garantisi vermez:** 4 ms hedefi ve chunk başı kota kontrolü vardır fakat UE tick iş yükü, GC veya eşzamanlı sistemler için hard real-time garantisi değildir.
- **Su kaynağı/kar/erozyon:** Yağış ve su hücreleri temel düzeydedir; karın erimesi, akifer, erozyon/toprak taşınması, yapı hasarı ve kimya diffusion event'i otomatik oyun sonucu üretmek üzere tamamlanmamıştır.
- **Load sırasında dış sistem yeniden bağlama:** Dünya saati ve chunk store geri yüklenir; actor referansları/responder kayıtları save dosyasından geri kurulmaz, bunlar level/actor BeginPlay sırasında yeniden kaydedilmelidir.
- **Kayıt uyumluluğu:** Birleşik Material paketi binary format v4 yazar ve önceki v3 kayıtlarını extension payload alanı olmadan okuyabilir. Gelecek şema değişikliklerinde sürüm yükseltilmeli ve uyumluluk/migration açıkça test edilmelidir.

## Kullanılacak ana dosyalar

- `README_WORLDSTATE_TR.md`: kurulum ve davranış.
- `WORLD_DATA_ASSETS_TR.md`: ayar tablosu ve alan hesabı.
- `BUILD_CS_WORLDSTATE_PATCH_TR.md`: add-on kullanıcıları için Build.cs klasörleri.
- `Scripts/check_worldstate_source.py`: yeniden çalıştırılabilir statik denetim.
