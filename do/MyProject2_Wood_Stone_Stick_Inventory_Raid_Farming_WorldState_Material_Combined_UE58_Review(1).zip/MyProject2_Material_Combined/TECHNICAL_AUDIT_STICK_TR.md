# Teknik denetim — Stick sistemi

## Paketlemede giderilen/eklenenler
- Kaynak ağacına stick modülleri eklendi.
- Kullanıcı kodunda `AStickActor` tarafından kullanılan fakat dosyası olmayan `UStickStateMachine` eklendi.
- `EConnectionType` için `Woven`, `Bound`, `Lashed` değerleri eklendi; bağlama türleri artık `Mortared` olarak etiketlenmiyor.
- `UStickInventoryComponent::AddSticks` içindeki kapasite ve tekrar ekleme hatası düzeltildi; mevcut demetlerde kalan alan dolduruluyor, yeni demetler yalnızca kalan miktar için oluşturuluyor.
- Çubuk stack'e eklenirken Carried durumu geçişi kontrol ediliyor.
- Bazı null/range ve zamanlayıcı koşulları sıkılaştırıldı.

## Derleme/test durumu
Bu ortamda UE 5.8 Unreal Build Tool / Unreal Editor çalıştırılmadı. `check_source_layout.py` statik dosya/include kontrolüdür, C++/UHT derleme doğrulaması değildir. Aşağıdaki konular UE tarafında ayrıca doğrulanmalıdır:
- Unreal Header Tool'un bütün UPROPERTY/UFUNCTION makrolarını kabul etmesi.
- Header include sırası ve platforma özgü API değişiklikleri.
- Default Subobject attachment/collision/physics davranışları.

## Önemli oynanış eksikleri
- `UStickInventoryComponent` şimdilik ad-temelli basit sayım envanteri; fiziksel `AStickActor` nesneleri ile otomatik eşgüdümlü değildir.
- `UStickStackComponent::AddBundle` yalnızca kabul edilen adet sayısını döndürür; bundle'ı fizik nesnelerine dönüştürmez.
- `UCraftingComponent` shape/tool şartlarını tam doğrulamaz; envanter tüketimi/çıktı ekleme için üretim öncesi rezervasyon veya transaction gerekir.
- `StickActor::ApplyShape` tanımı değiştirir, mesh geometrisini üretmez/değiştirmez.
- Hasar uygulama, AI perception, trap trigger volume overlap, weather input, bird spawn ve hayvan simülasyonu proje alt sistemlerine bağlanmamış hook'lar içerir.
- `UStickDurabilityComponent` ayrı health tutar; actor health ile çift kaynak oluşturabileceğinden production aşamasında tek otorite belirlenmeli.
- Nem durumu `UStickMoistureComponent` üzerinde tutuluyor; yanma süresi ve ateşlenebilirlik ile doğrudan entegre değil.
- Wattle örgü bağlantıları grafik ilişkisidir; spline/mesh üretimi ve gerilim çözümü yoktur.
- Replication/save/load yoktur.

## Önerilen doğrulama sırası
1. Editor target derlemesi ve UHT hataları.
2. `DA_StickRaw` ile actor spawn/initialize.
3. toplama, bırakma ve envanter kapasitesi testleri.
4. iki çubuğun ortak graf üzerinden örülmesi ve iki taraflı disconnect.
5. nem/yanma davranışları ve dayanıklılık tek kaynak kararı.
6. crafting transaction ve kayıt/yükleme entegrasyonu.
7. tuzaklar ve AI olayları.
