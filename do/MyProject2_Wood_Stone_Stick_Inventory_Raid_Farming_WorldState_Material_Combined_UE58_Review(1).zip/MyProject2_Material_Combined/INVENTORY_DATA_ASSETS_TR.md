# Inventory Data Asset Kurulumu

## Item Data Assets (`Content/Inventory/Items/`)
`UInventoryItemData` tabanlı Primary Data Asset'ler oluşturun. Örnek `ItemID` değerleri: `cloth`, `rope`, `bone`, `leaf`, `feather`, `herb`, `bottle`, `alcohol`, `sap`, `flint`, `resin`, `honey`, `berry`, `medicine_herb`, `energy_mix`, `bandage`, `molotov`, `grenade`, `stone_arrow`, `bone_arrow`, `bone_armor`, `leather_armor`, `poison_coating`, `fire_coating`, `repair_tool`, `stick`, `stone`, `tree_sap`, `fiber`, `leather`.

Her asset'te ItemID benzersiz olmalı. `MaxStack` ve `Weight` pozitif/negatif olmayan değerlerle ayarlanmalı. `bStackable=false` ise MaxStack değeri 1 kullanılır. Asset'leri player inventory component `ItemDefinitions` dizisine eklemek kayıt (registration) için en net yoldur.

## Recipe Data Assets (`Content/Inventory/Recipes/`)
`UCraftingRecipeAsset` örnekleri: `DA_Recipe_Molotov`, `DA_Recipe_Bandage`, `DA_Recipe_EnergyMix`, `DA_Recipe_Rope`, `DA_Recipe_StoneArrow`, `DA_Recipe_BoneArrow`, `DA_Recipe_BoneArmor`, `DA_Recipe_LeatherArmor`, `DA_Recipe_PoisonCoating`, `DA_Recipe_FireCoating`, `DA_Recipe_RepairTool`, `DA_Recipe_Grenade`, `DA_Recipe_Sap`. Her recipe'nin `RecipeID`, ingredients ve output ID'leri item asset'lerinde tanımlı olmalıdır. `bIsTool=true` girdiler araç olarak doğrulanır ve `bConsumed=false` ayarlanması önerilir.

Not: Tariflerin `Conditions` alanı için dünya/çevre sağlayıcısı ayrıca bağlanmalıdır; içerik içinde otomatik çevresel kontrol bulunmaz.
