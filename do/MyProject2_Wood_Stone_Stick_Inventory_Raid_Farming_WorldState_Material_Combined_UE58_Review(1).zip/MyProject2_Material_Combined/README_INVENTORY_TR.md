# MyProject2 — Inventory & Crafting (UE 5.8 review package)

Bu paket envanter, dünya eşyası pickup/drop, tarif/recipe matching, keşif, UI durum adaptörleri, ürün davranışları ve fiziksel kaynak köprülerini ekler.

## İçerik
- `Source/MyProject2/InventoryCore`: item data assets, stack/weight/slot inventory, quick access ve gerçek `USaveGame` slot kaydı.
- `InventoryWorld`: yere bırakılan item aktörleri, pickup/drop.
- `InventoryCrafting`: recipe assets, 6 slotlu combining area, matcher, validator, discovery.
- `InventoryUI`: Blueprint/UMG katmanına bağlanabilecek durum adaptörleri; bunlar kendileri Widget oluşturmaz.
- `InventoryProducts`: consumable data, armor, thrown weapon, upgrades, repair entegrasyon noktası.
- `InventoryBridge`: physical log/stone/stick ile inventory ID katmanı arasında transfer.

## Kurulum
1. Önce `MyProject2_Wood_Stone_Stick_Combined_UE58_Review.zip` içeriğini temel alın (birleşik pakette kaynakların tamamı zaten vardır).
2. Bu arşivdeki `Source/MyProject2/Inventory*` klasörlerini ve güncel `MyProject2.Build.cs` dosyasını kopyalayın.
3. `Content/Inventory/Items` altında `UInventoryItemData` tabanlı Primary Data Asset oluşturun. Her InventoryComponent'in `ItemDefinitions` alanına item asset'lerini ekleyin.
4. `Content/Inventory/Recipes` altında `UCraftingRecipeAsset` oluşturun ve ilgili `URecipeMatcher.RecipeAssets` / `URecipeDiscoveryComponent.KnownRecipes` listelerine tanımları ekleyin.
5. Proje dosyalarını yeniden oluşturun ve `MyProject2Editor` hedefini UE 5.8 ile derleyin.

## Tasarım düzeltmeleri
- Inventory `FInventoryItem::Count` varsayılanı 0'dır; boş slotlar yanlışlıkla dolu sayılmaz.
- `FInventoryCraftingIngredient` adı, çubuk sistemindeki `FCraftingIngredient` ile global isim çakışmasını önler.
- AddItem kapasite/ağırlık denetimini ekleme öncesi yapar ve kısmi eklemeyi önlemeye çalışır.
- Save/Load `UGameplayStatics::SaveGameToSlot` ve `LoadGameFromSlot` kullanır; önceki RAM cache yaklaşımı değildir.
- Physical-to-inventory transfer ancak item başarıyla eklendiğinde fiziksel aktörü kaldırır. Inventory-to-physical, spawn başarısızsa item tüketmez.

## Bilinen kapsam sınırları
- `InventoryUIComponent` / radial UI sınıfları durum adaptörüdür; UMG widget görselleri ve input bağları Blueprint'te kurulmalıdır.
- Çevre koşulları (`NearFire`, `NearWater`, hava) validator içinde şimdilik entegrasyon noktasıdır.
- Consumable efektleri karakterin sağlık/susuzluk vb. bileşenlerine bağlanmalıdır. Hasar dağıtımı ve gerçek onarım için ortak bir `IDamageable`/`IRepairable` arayüzü gerekir; repair metotları yanlış başarı bildirmemek için eksik entegrasyonu açıkça reddeder.
- Physical-to-inventory dönüşümünde oyuncu/oyun mantığı, uygun item ID tanımı ve miktar eşlemesini sağlamalıdır. Inventory-to-physical actor sınıfları Blueprint child ve DataAsset eşlemesiyle initialize edilmelidir.
- Kaynak paketinin Unreal Build Tool ile derlemesi bu ortamda çalıştırılmadı. Statik kaynak/başlık/include kontrolleri UE derleme doğrulaması değildir.
