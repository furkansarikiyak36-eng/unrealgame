using UnrealBuildTool;
using System.IO;

public class MyProject2 : ModuleRules
{
    public MyProject2(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(new string[] {
            "Core", "CoreUObject", "Engine", "InputCore", "PhysicsCore",
            "AIModule", "GameplayTasks", "NavigationSystem"
        });
        PrivateDependencyModuleNames.AddRange(new string[] { "RenderCore", "RHI" });
        PublicIncludePaths.Add(ModuleDirectory);
        string[] Folders = new string[] {
            "Core",
            "InventoryBridge",
            "InventoryCore",
            "InventoryCrafting",
            "InventoryProducts",
            "InventoryUI",
            "InventoryWorld",
            "Phase1_Physical",
            "Phase2_Transport",
            "Phase3_Cutting",
            "Phase4_Construction",
            "Phase5_Structural",
            "Phase6_Utility",
            "Phase7_Integration",
            "StickCore",
            "StickPhaseS1_Core",
            "StickPhaseS2_Processing",
            "StickPhaseS3_Crafting",
            "StickPhaseS4_Fire",
            "StickPhaseS5_Defense",
            "StickPhaseS6_Traps",
            "StickPhaseS7_Furniture",
            "StickPhaseS8_Environment",
            "StickPhaseS9_Extensions",
            "StoneCore",
            "StonePhaseA_Mining",
            "StonePhaseB_Placement",
            "StonePhaseC_Structural",
            "StonePhaseD_Processing",
            "StonePhaseE_Functional",
            "StonePhaseF_Environment",
            "StonePhaseG_Logistics",
            "RaidCore",
            "RaidPhaseR1_Trigger",
            "RaidPhaseR2_Difficulty",
            "RaidPhaseR3_Planner",
            "RaidPhaseR4_Budget",
            "RaidPhaseR5_Spawn",
            "RaidPhaseR6_Targeting",
            "RaidPhaseR7_Navigation",
            "RaidPhaseR8_Defense",
            "RaidPhaseR9_WaveState",
            "RaidPhaseR10_Crosscutting",
            "RaidPhaseR11_Testing",
            "SimCore",
            "PhaseT2_Plant",
            "PhaseT3_Soil",
            "PhaseT4_Stress",
            "PhaseT5_Harvest",
            "PhaseT6_Animal",
            "PhaseT7_Production",
            "PhaseT8_Reproduction",
            "PhaseT9_Integration",
            "WorldCore",
            "WorldPhaseW1_Chunk",
            "WorldPhaseW2_Lazy",
            "WorldPhaseW3_Event",
            "WorldPhaseW4_WaterSoil",
            "WorldPhaseW5_FireDecayChem",
            "WorldPhaseW6_Persistence",
            "MaterialCore",
            "MaterialPhaseM1_Definition",
            "MaterialPhaseM2_Interaction",
            "MaterialPhaseM3_Instance",
            "MaterialPhaseM4_Composite",
            "MaterialPhaseM5_PlasterMetal",
            "MaterialPhaseM6_Integration",
        };
        foreach (string Folder in Folders)
            PublicIncludePaths.Add(Path.Combine(ModuleDirectory, Folder));
    }
}
