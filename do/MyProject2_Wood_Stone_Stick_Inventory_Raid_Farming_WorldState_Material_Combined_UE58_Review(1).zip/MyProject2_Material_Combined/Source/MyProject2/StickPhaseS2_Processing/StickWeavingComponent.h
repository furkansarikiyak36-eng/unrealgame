#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "StickWeavingComponent.generated.h"
class AStickActor; UCLASS(ClassGroup=(Stick),meta=(BlueprintSpawnableComponent)) class MYPROJECT2_API UStickWeavingComponent:public UActorComponent{GENERATED_BODY() public: UStickWeavingComponent(); UFUNCTION(BlueprintCallable) bool WeaveHorizontal(AStickActor*,AStickActor*); UFUNCTION(BlueprintCallable) bool WeaveCross(AStickActor*,AStickActor*); UFUNCTION(BlueprintCallable) bool CreateWattlePanel(const TArray<AStickActor*>&,const TArray<AStickActor*>&); UPROPERTY(EditAnywhere,BlueprintReadWrite) float WeaveTension=.5f; UPROPERTY(EditAnywhere,BlueprintReadWrite) int32 RowsPerPanel=6;};
