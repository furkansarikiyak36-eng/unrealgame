# Taş Data Asset Kurulumu (UE 5.8)

`Content/Stone/Definitions/` altında `UStoneDefinition` tabanlı Data Asset'ler oluşturun. Aşağıdaki boyutlar Unreal cm, kütle kg, `Volume` ise m³ olarak yorumlanır. Mesh'in başlangıç boyutları `AStoneActor::ApplyShape` içinde kullanılan ölçek referansıyla uyumlu olmalıdır; en güvenlisi her şekil için doğru boyutta mesh atamaktır.

| Asset | Shape | Type | Mass (kg) | Dimensions (cm) | Volume (m³) |
|---|---|---|---:|---|---:|
| `DA_SmallStone` | Small | Granite | 2 | 10×10×8 | 0.0008 |
| `DA_BuildingStone` | Building | Granite | 25 | 30×20×20 | 0.0120 |
| `DA_FlatStone` | Flat | Slate | 15 | 40×40×10 | 0.0160 |
| `DA_CarvedStone` | Carved | Limestone | 20 | 35×25×20 | 0.0175 |
| `DA_Boulder` | Boulder | Granite | 200 | 80×80×60 | 0.3840 |
| `DA_Rubble` | Rubble | Granite (veya projede tanımlı tür) | 8 | 20×20×15 | 0.0060 |
| `DA_Gravel` | Gravel | Granite (veya projede tanımlı tür) | 1 | 10×10×5 | 0.0005 |
| `DA_Voussoir` | Voussoir | Sandstone | 18 | 25×20×25 | 0.0125 |
| `DA_Keystone` | Keystone | Sandstone | 22 | 30×20×25 | 0.0150 |

## Gerekli alanlar

- `StoneName`: boş bırakılmamalı.
- `Type`, `Shape`, `Role`: doğru tür ve yapısal role atanmalı.
- `Dimensions`, `Mass`, `Volume`: ValidateDefinition dönüşüyle tutarlı olmalı.
- `CompressiveStrength`, `TensileStrength`, `StaticFriction`, `RollingResistance`, `WeatheringRate`, `HeatConductivity`: prototipte oyun ölçekli sayılardır; fiziksel ölçüm verisi değildir.
- `Mesh`, `Material`: gerçek Content Browser asset'lerine atanmalı.
- `Sockets`, `Faces`: placement ve bağlantı sistemleri için ihtiyaç duyulan socket/normal alanları girilmeli. Kodun mevcut hâli tüm bu verileri otomatik kullanmıyor.

## Notlar

1. `CanStackOn` mevcut taslakta `Mass` ve `CompressiveStrength` karşılaştırmasını kaba bir eşik olarak kullanır; mühendislik tipi yük hesabı değildir.
2. `ApplyShape` mevcut mesh'i ölçekler. Taşın kesilmiş/yontulmuş gerçek silueti için ayrı mesh varyantları veya `ProceduralMeshComponent`/Geometry Script tabanlı üretim gerekir.
3. `DA_Rubble` / `DA_Gravel` mesh'lerini ayrı, düşük maliyetli varyantlar olarak üretin; her kırılma olayında ağır taş mesh'i çoğaltmayın.
