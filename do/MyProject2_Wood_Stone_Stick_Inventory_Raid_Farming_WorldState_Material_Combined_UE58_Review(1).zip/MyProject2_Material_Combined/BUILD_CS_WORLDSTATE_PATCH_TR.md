# Build.cs — W1–W6 include klasörleri

Mevcut `MyProject2.Build.cs` içindeki `Folders` dizisine şu öğeleri ekleyin (birleştirilmiş arşivde bu işlem zaten uygulanmıştır):

```csharp
"WorldCore",
"WorldPhaseW1_Chunk",
"WorldPhaseW2_Lazy",
"WorldPhaseW3_Event",
"WorldPhaseW4_WaterSoil",
"WorldPhaseW5_FireDecayChem",
"WorldPhaseW6_Persistence",
```

Bu modüller aynı `MyProject2` runtime modülü içinde kalır; Unreal Build.cs içinde ayrı C++ modülleri değildir.
