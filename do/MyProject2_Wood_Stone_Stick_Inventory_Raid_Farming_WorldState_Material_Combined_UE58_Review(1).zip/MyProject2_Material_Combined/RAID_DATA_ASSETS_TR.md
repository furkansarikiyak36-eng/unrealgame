# Raid Data Asset Kurulumu

CSV dosyaları örnek veri şemasıdır; Unreal `.uasset` değildir. Unreal Editor'da C++ sınıflarına karşılık Data Asset oluşturup satırları elle veya Editor Utility ile aktar.

## Stage Table (`URaidStageTableAsset`)
Kaynak: `Content/Raid/Stages/DA_StageTable_Default.example.csv`

- `StageIndex`: plan varlıklarının `StageIndex` alanıyla eşleşir.
- `Threshold`: puan alt sınırı; benzersiz ve artan olmalıdır.
- `Budget.ConcurrentPopulation`: aynı anda canlı tutulacak düşman kapasitesi.
- `Budget.TotalBudget`: tasarım verisidir; örnek ana akışta wave başına `FWavePlan.TotalCount` spawn bütçesi kullanılır.
- `PlanID`: dokümantasyon/bağlantı alanı; şu an plan seçicisi esas olarak `StageIndex` üzerinden eşleştirir.

## Horde Plan (`UHordePlanAsset`)
Kaynak: `Content/Raid/Plans/DA_Plan_Early.example.csv`

Her wave için `GroupID`, `TotalCount`, `MaxAlive`, `Duration` ve `Intermission` doldur. Her `GroupID`, Enemy Group Library içindeki bir grupla aynı olmalıdır.

## Enemy Group Library (`UEnemyGroupLibrary`)
Kaynak: `Content/Raid/Groups/DA_EnemyGroups.example.csv`

Her grup bir veya daha çok `FWeightedEntry` içerir. Ağırlığı sıfır ya da negatif olan üyeler seçim olasılığına katkı vermez.

## Enemy Library (`UEnemyLibrary`)
Kaynak: `Content/Raid/Groups/DA_Enemies.example.csv`

Her Enemy ID için `EnemyClass` atanmalı. CSV'deki `BP_Enemy_*` isimleri varsayımsal Blueprint adlarıdır; projede bu Blueprint'leri sen oluşturmalısın. `BaseHealth`, `BaseDamage`, `MoveSpeed` ve `ThreatLevel` verileri için ayrıca Enemy Stats/Attribute Component adaptörü bağlanmalıdır; ana subsistem şu an sadece sınıfı spawn eder.

## Runtime bağlama
Oyunun GameMode, PlayerController/manager Actor veya benzeri başlangıç noktasından:

1. `GetWorld()->GetSubsystem<URaidDirectorSubsystem>()` ile subsystem'i al.
2. Stage Table, Horde Plan array'i, Enemy Group Library ve Enemy Library varlıklarını yükle.
3. `ConfigureRaidAssets(StageTable, Plans, Groups, Enemies)` çağır.
4. Uygun gameplay olayı geldiğinde `StartRaid(EventID, EventType)` çağır.

World Subsystem özellikleri level'da yerleştirilen Actor Details panelinden yapılandırılamadığı için bu explicit binding gereklidir.
