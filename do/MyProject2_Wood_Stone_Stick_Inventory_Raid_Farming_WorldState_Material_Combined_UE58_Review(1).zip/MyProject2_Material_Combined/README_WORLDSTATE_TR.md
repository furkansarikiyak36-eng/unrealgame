# MyProject2 — World State Simulation W1–W6

## İçerik

Bu katman, MyProject2'nin `Source/MyProject2/` dizinine eklenen 6 fazı içerir: **WorldCore**, W1 Chunk Activation, W2 Lazy Evaluation, W3 Event Bus, W4 Water/Soil, W5 Fire/Decay/Chemistry ve W6 Persistence. `UWorldStateSubsystem`, dünya durum deposunu ve simülasyon servislerini yönetir.

- `WorldCore`: koordinat dönüşümleri, chunk hücreleri, dünya zamanı, chunk deposu ve komşuluk.
- `W1`: oyuncunun çevresindeki chunk durumlarının yüklenmesi ve Continuous / Scheduled / Passive aktivasyonları. Durum chunk'ları persistent store'da kalır; `UnloadChunk` yalnızca etkin kümeden çıkarır.
- `W2`: üstel/lineer/lojistik decay yardımcıları, çakışmasız sparse-cell anahtarı, olay zinciri takibi ve frame bütçesi.
- `W3`: sınırlı olay kuyruğu, responder arayüzü ve komşulara azalan büyüklükle yayılım.
- `W4`: hücre başına su/hacim, iki geçişli lokal su akışı, yüzey suyunun toprağa sızması, buharlaşma/perkolasyon ve arazi katmanı.
- `W5`: hücre sınırını aşarak yanlış komşuya sıçramayan yangın yayılımı, deterministik seed tabanlı zar, decay ve kimyasal difüzyon.
- `W6`: sürümlü binary kayıt biçimi, isteğe bağlı Zlib sıkıştırması, varsayılan olmayan hücrelerin sparse kaydı ve kayıtlı chunk'ların store'a geri yüklenmesi. Material eklentisi ile chunk başına değil, hücre indeksi başına opsiyonel `ExtensionCellPayloads` byte verisi de korunur.

## Alan ve chunk hesabı

Varsayılan chunk boyutu `64 × 64 m`, eksen başına `99` chunk, chunk başına `16 × 16` hücredir. Teorik harita kenarı `99 × 64 = 6.336 m`, kare alanı `6.336² = 40.144.896 m²`, yani yaklaşık **40,145 km²**. Dünya başlangıçta 9.801 chunk'ın tamamını ayırmaz; chunk'lar gerektiğinde oluşturulur.

`ChunkState` içindeki hücre dizisi yoğun `TArray` olarak tutulur (16×16 = 256 hücre/chunk). Temel çevresel state seyrek olarak kayıt edilir; `ExtensionCellPayloads` ise yalnızca state eklenmiş hücre anahtarları için byte payload tutar. Bu, ana hücre dizisinin bellekte sparse olduğu anlamına gelmez.

## Zaman ve aktivasyon

Varsa `USimulationSubsystem` (T1) tek saat kaynağı olarak kullanılır; gün, saat, sıcaklık, yağış, rüzgâr ve seed buradan okunur. `WorldSaveSubsystem` yükleme sonrasında bu saati geri eşitler. T1 yoksa `UWorldStateSubsystem` kendi `GameHoursPerRealSecond` ayarıyla ilerler.

- **Continuous**: her tick'te çalıştırılmaya adaydır; frame / chunk bütçesi nedeniyle işlem ertelenebilir.
- **Scheduled**: yaklaşık her 5 gerçek saniyede bir çalıştırılır.
- **Passive**: ağır fiziksel benzeri güncelleme yapmaz; yeniden etkinleşince son simülasyon gününden bugüne catch-up uygulanır.

`UChunkManager` oyuncunun çevresinde `ActivationRadius` kadar bir alanı (varsayılan 500 m) etkin kümede tutar. Kalıcı state, etkin kümeden çıkarılınca silinmez.

## Kurulum

1. Arşivin `Source/MyProject2/WorldCore` ve `WorldPhaseW*` klasörlerini mevcut projenizde aynı konuma kopyalayın. Birleştirilmiş pakette tüm önceki modüller ve güncel `MyProject2.Build.cs` de bulunur.
2. Birleştirilmiş paketin `MyProject2.Build.cs` dosyası W1–W6 include dizinlerini ekler. Add-on arşivinde uygulanacak klasörler `BUILD_CS_WORLDSTATE_PATCH_TR.md` içinde listelenir.
3. `ACharacter`/oyuncu Pawn'ına `UChunkManager` bileşeni ekleyin. Bileşenin `Policy` değerini editörde `UChunkActivationPolicy` nesnesiyle yapılandırın veya varsayılanı kullanın.
4. `Content/World/Settings/DA_WorldSettings.example.csv` örnek yapılandırmadır; **Unreal `.uasset` değildir**. `FWorldChunkSettings` alanları şu an `UWorldStateSubsystem` üzerinde düzenlenir. `.uasset` Data Asset kurulumu henüz yapılmadı.
5. Kaydetme/yükleme için `UWorldSaveSubsystem` üzerinden `SaveWorld("SlotName")` ve `LoadWorld("SlotName")` çağırın. Dosyalar `Saved/World/<SlotName>.bin` yoluna yazılır. Slot adı geçerli dosya adına dönüştürülür.
6. `Scripts/build_ue5_windows.bat "C:\Path\MyProject2.uproject"` komutunu, `UE_5_8_BUILD_BAT` ortam değişkeni ile kendi UE 5.8 `Build.bat` yolunuzu belirterek çalıştırabilirsiniz.

## Önemli kullanım notları

- `UWorldStateSubsystem` doğrudan tarım/raid/enventer alt sistemlerinin Actor durumlarını kendiliğinden serialize etmez. Chunk state ve dünya saati kaydedilir; `AAnimalActor`, `ACropFieldActor`, envanter ve Raid Director'ın kendi kayıt köprüleri ayrıca bağlanmalıdır.
- Dünya event'i üretmek için `UWorldEventSubsystem::BroadcastEvent` kullanılır. Olay responder'ları `RegisterResponder` ile açıkça kaydedilir; her actor otomatik keşfedilmez.
- Su akışı şu an her chunk'ın kendi 2D hücre ızgarasında çalışır. Chunk sınırını aşan hidrolik akış, gerçek yükseklik raster'ı, kanal topolojisi ve terrain collision ile otomatik bağlanmış değildir.
- Pasif chunk'lar için geçmiş günlük hava olayları ayrı ayrı dosyalanmaz. Yağış toplamı deterministik seed ve gün numarasından yeniden oluşturulur; içinde bulunulan günün aktif hava değeri kullanılır. Ancak sıcaklık/rüzgâr tarihçesi ve kar örtüsü ayrıca modellenmediğinden uzun süreli catch-up'ın tamamı meteorolojik açıdan birebir değildir. Kar yağışı şimdilik su hacmine çevrilir; kar birikimi/erimesi katmanı yoktur.
- `UWorldChunkSubsystem::UnloadChunk` render/actor stream işlemi yapmaz; yalnızca simülasyon etkin kümesinden çıkarır. Unreal World Partition/level streaming ayrıca bağlanmalıdır.
- Bu arşivde `.uasset`, `.umap` veya `.uproject` üretilmemiştir; kaynak modülleridir.

## Doğrulama

`Scripts/check_worldstate_source.py` kaynak yapısı, `.generated.h` sırası, modül include referansları, Build.cs klasörleri ve temel matematik/alan varsayımlarını kontrol eder. Bu **statik kontrol**, Unreal Header Tool veya C++ derlemesi değildir. Bu çalışma ortamında UnrealBuildTool/UE 5.8 kurulumu bulunmadığından gerçek derleme ve PIE testi çalıştırılamadı; sonucu audit dosyasında açıkça belirtilir.

## Material eklentisi ve save sürümü

World State kayıt biçimi Material M6 entegrasyonu ile **v4** olarak yazılır. v3 kayıtlar, eski sürümde extension alanı bulunmadığı varsayılarak geriye dönük yüklenir; bu kayıtlarda `ExtensionCellPayloads` boş başlar. Material instance snapshotları `UMaterialChunkIntegration::SetChunkCellMaterialState` üzerinden eklenir ve W6 serializer tarafından saklanır.
