// MaterialProperties.cpp
#include "MaterialProperties.h"

float FMaterialProperties::GetProperty(EMaterialProperty Property) const
{
    switch (Property)
    {
        case EMaterialProperty::Density:             return Density;
        case EMaterialProperty::Hardness:            return Hardness;
        case EMaterialProperty::ImpactResistance:    return ImpactResistance;
        case EMaterialProperty::CompressionStrength: return CompressionStrength;
        case EMaterialProperty::TensileStrength:     return TensileStrength;
        case EMaterialProperty::Brittleness:         return Brittleness;
        case EMaterialProperty::Flammability:        return Flammability;
        case EMaterialProperty::FuelValue:           return FuelValue;
        case EMaterialProperty::WaterAbsorption:     return WaterAbsorption;
        case EMaterialProperty::WaterDamageRate:     return WaterDamageRate;
        case EMaterialProperty::DecayRate:           return DecayRate;
        case EMaterialProperty::Workability:         return Workability;
    }
    return 0.0f;
}

void FMaterialProperties::SetProperty(EMaterialProperty Property, float Value)
{
    switch (Property)
    {
        case EMaterialProperty::Density:             Density = Value; break;
        case EMaterialProperty::Hardness:            Hardness = Value; break;
        case EMaterialProperty::ImpactResistance:    ImpactResistance = Value; break;
        case EMaterialProperty::CompressionStrength: CompressionStrength = Value; break;
        case EMaterialProperty::TensileStrength:     TensileStrength = Value; break;
        case EMaterialProperty::Brittleness:         Brittleness = Value; break;
        case EMaterialProperty::Flammability:        Flammability = Value; break;
        case EMaterialProperty::FuelValue:           FuelValue = Value; break;
        case EMaterialProperty::WaterAbsorption:     WaterAbsorption = Value; break;
        case EMaterialProperty::WaterDamageRate:     WaterDamageRate = Value; break;
        case EMaterialProperty::DecayRate:           DecayRate = Value; break;
        case EMaterialProperty::Workability:         Workability = Value; break;
    }
}

float FMaterialProperties::CompareHardness(const FMaterialProperties& Other) const
{
    if (Other.Hardness <= 0.0f) return 1.0f;
    return FMath::Clamp(Hardness / Other.Hardness, 0.0f, 10.0f);
}
