#!/usr/bin/env python3
"""Reference arithmetic checks for the material formulas, not a UE/C++ runtime test."""
import math

def close(a, b, tol=1e-8):
    return abs(a-b) <= tol

checks = {}
# Wood profile: 0.8 flammability, 400C ambient and 200C ignition threshold, 24h => 1 day.
checks['fire_damage_one_day'] = close(0.8 * ((400.0-200.0)/200.0) * (24.0/24.0), 0.8)
# Plaster profile: waterDamage=.8, absorption=.8, moisture=.8, 24h => .512 damage score.
checks['water_damage_one_day'] = close(0.8 * (0.8*0.8) * (24.0/24.0), 0.512)
# Stone impact profile: magnitude 100 - resistance 70*0.5, then brittleness multiplier 1.7.
checks['impact_damage'] = close(max(0.0, 100.0 - 70.0*0.5) * (1.0+0.7), 110.5)
# Time decay: rate .02/day, temperature factor 1.16, moisture factor 1.5 for one day.
checks['time_damage_one_day'] = close(0.02 * 1.16 * 1.5 * 1.0, 0.0348)
# Exponential update uses B(t) = B0 * exp(-k*dt).
checks['exponential_biomass_update'] = close(100.0 * math.exp(-0.0348), 96.57985566542139)
# Last test: normalized decay must be monotonic and non-negative.
values=[100.0*math.exp(-0.02*d) for d in (0,1,2,5,10)]
checks['decay_monotonic'] = all(a >= b >= 0.0 for a,b in zip(values,values[1:]))
for name, ok in checks.items(): print(f'{name}: {"PASS" if ok else "FAIL"}')
print(f'Total: {sum(checks.values())}/{len(checks)}')
raise SystemExit(0 if all(checks.values()) else 1)
