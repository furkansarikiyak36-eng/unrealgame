#!/usr/bin/env python3
"""Idempotently adds optional common-material references to legacy definitions.

Run after copying the add-on Source/MyProject2/Material* folders into the target module:
python Scripts_apply_material_legacy_bridge.py --source-dir <Project>/Source/MyProject2
"""
from pathlib import Path
import argparse
import sys

def replace_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if old not in text:
        raise RuntimeError(f"Expected insertion point not found for {label}")
    return text.replace(old, new, 1)

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-dir', required=True, help='Target Source/MyProject2 directory')
    args = parser.parse_args()
    root = Path(args.source_dir).expanduser().resolve()
    targets = {
        'Core/LogDefinition.h': [
            ('class UMaterialInterface;\n', 'class UMaterialInterface;\nclass UMaterialDefinition;\n', 'log forward declaration'),
            ('    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Identity") FName LogType = NAME_None;\n', '    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Identity") FName LogType = NAME_None;\n    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Material") TSoftObjectPtr<UMaterialDefinition> CommonMaterialDefinition;\n', 'log property'),
        ],
        'StoneCore/StoneDefinition.h': [
            ('class UMaterialInterface;\n', 'class UMaterialInterface;\nclass UMaterialDefinition;\n', 'stone forward declaration'),
            ('    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity") FName StoneName;\n', '    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity") FName StoneName;\n    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Material") TSoftObjectPtr<UMaterialDefinition> CommonMaterialDefinition;\n', 'stone property'),
        ],
        'StickCore/StickDefinition.h': [
            ('#include "StickTypes.h"\n', '#include "StickTypes.h"\nclass UMaterialDefinition;\n', 'stick forward declaration'),
            ('    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Identity") FName StickName;\n', '    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Identity") FName StickName;\n    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Material") TSoftObjectPtr<UMaterialDefinition> CommonMaterialDefinition;\n', 'stick property'),
        ],
    }
    for rel, patches in targets.items():
        p = root / rel
        if not p.exists():
            raise RuntimeError(f"Missing target file: {p}")
        text = p.read_text(encoding='utf-8')
        for old, new, label in patches:
            text = replace_once(text, old, new, label)
        p.write_text(text, encoding='utf-8')
    print('Legacy material reference fields are installed (or already present).')
    print('Next: add the seven Material* folders to MyProject2.Build.cs and run the UE 5.8 build.')
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        raise SystemExit(2)
