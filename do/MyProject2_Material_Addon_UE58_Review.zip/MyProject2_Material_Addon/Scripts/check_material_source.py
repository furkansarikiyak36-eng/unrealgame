#!/usr/bin/env python3
"""Static structural checks for Material & Substance Simulation M1-M6.
Does not run UnrealBuildTool/UnrealHeaderTool and is not a compiler test.
"""
from pathlib import Path
import argparse, hashlib, json, re, sys

DIRS = [
    'MaterialCore', 'MaterialPhaseM1_Definition', 'MaterialPhaseM2_Interaction',
    'MaterialPhaseM3_Instance', 'MaterialPhaseM4_Composite',
    'MaterialPhaseM5_PlasterMetal', 'MaterialPhaseM6_Integration'
]
BRIDGE_FILES = [
    'Core/LogDefinition.h', 'StoneCore/StoneDefinition.h', 'StickCore/StickDefinition.h',
    'WorldCore/ChunkState.h', 'WorldPhaseW6_Persistence/ChunkSerializer.h',
    'WorldPhaseW6_Persistence/ChunkSerializer.cpp', 'WorldPhaseW6_Persistence/WorldPersistence.h',
    'WorldPhaseW6_Persistence/WorldPersistence.cpp', 'MyProject2.Build.cs'
]
BASE_PROJECT_INCLUDES = {
    'Core/LogDefinition.h', 'StoneCore/StoneDefinition.h', 'StickCore/StickDefinition.h',
    'WorldCore/ChunkState.h', 'WorldPhaseW2_Lazy/ExponentialDecayModel.h',
    'WorldPhaseW3_Event/WorldEventSubsystem.h'
}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project-root', default=str(Path(__file__).resolve().parent.parent), help='Package root containing Source/MyProject2')
    args = ap.parse_args()
    package = Path(args.project_root).resolve()
    root = package / 'Source' / 'MyProject2'
    errors, warnings = [], []
    headers, cpps = [], []
    # An overlay add-on intentionally omits legacy/base project files. Validate the bridge patch there.
    addon_mode = not (root / 'WorldCore/ChunkState.h').exists() and not (root / 'Core/LogDefinition.h').exists()
    for d in DIRS:
        folder = root / d
        if not folder.is_dir():
            errors.append(f'missing material module folder: {d}')
            continue
        headers += list(folder.rglob('*.h'))
        cpps += list(folder.rglob('*.cpp'))
    if len(headers) != 35: errors.append(f'expected 35 material headers from provided file blocks; found {len(headers)}')
    if len(cpps) != 33: errors.append(f'expected 33 material cpp files from provided file blocks; found {len(cpps)}')

    all_headers = list(root.rglob('*.h'))
    names = {p.name for p in all_headers}
    for p in headers:
        text = p.read_text(encoding='utf-8', errors='replace')
        generated = list(re.finditer(r'^\s*#include\s+["<][^">]*\.generated\.h[">]', text, re.M))
        includes = list(re.finditer(r'^\s*#include\s+', text, re.M))
        if not generated:
            errors.append(f'{p.relative_to(root)} missing generated.h include')
        elif includes and generated[-1].start() < includes[-1].start():
            errors.append(f'{p.relative_to(root)} generated.h is not the final include')
        for struct_match in re.finditer(r'USTRUCT\([^\n]*\)\s*\n\s*struct\s+\w+[^\{]*\{', text):
            close_match = re.search(r'^};\s*$', text[struct_match.end():], re.M)
            if close_match:
                struct_body = text[struct_match.end():struct_match.end()+close_match.start()]
                if re.search(r'\bUFUNCTION\s*\(', struct_body):
                    errors.append(f'{p.relative_to(root)} appears to place UFUNCTION inside a USTRUCT')

    # Verify quoted project-local includes against the module tree. External Engine includes are naturally absent.
    for p in headers + cpps:
        text = p.read_text(encoding='utf-8', errors='replace')
        for inc in re.findall(r'^\s*#include\s+"([^"]+)"', text, re.M):
            if inc.endswith('.generated.h'):
                continue
            if inc.startswith(('CoreMinimal.h', 'UObject/', 'Components/', 'Engine/', 'GameFramework/', 'Subsystems/', 'Serialization/', 'Misc/', 'HAL/', 'Kismet/', 'Containers/')):
                continue
            if addon_mode and inc in BASE_PROJECT_INCLUDES:
                continue
            candidates = [p.parent / inc, root / inc]
            candidates.extend(folder / inc for folder in root.iterdir() if folder.is_dir())
            if not any(c.exists() for c in candidates) and Path(inc).name not in names:
                errors.append(f'{p.relative_to(root)} unresolved project include: {inc}')

    # Brace count check after removing comments and strings.
    for p in headers + cpps:
        text = p.read_text(encoding='utf-8', errors='replace')
        stripped = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
        stripped = re.sub(r'//.*', '', stripped)
        stripped = re.sub(r'"(?:\\.|[^"\\])*"', '""', stripped)
        if stripped.count('{') != stripped.count('}'):
            errors.append(f'{p.relative_to(root)} brace count mismatch')

    build = root / 'MyProject2.Build.cs'
    build_text = build.read_text(encoding='utf-8', errors='replace') if build.exists() else (package / 'BUILD_CS_MATERIAL_PATCH_TR.md').read_text(encoding='utf-8') if (package / 'BUILD_CS_MATERIAL_PATCH_TR.md').exists() else ''
    for d in DIRS:
        if f'"{d}"' not in build_text:
            errors.append(f'Build.cs or patch doc missing {d}')

    for rel in ['Core/LogDefinition.h', 'StoneCore/StoneDefinition.h', 'StickCore/StickDefinition.h']:
        f = root / rel
        if f.exists() and 'CommonMaterialDefinition' not in f.read_text(encoding='utf-8', errors='replace'):
            errors.append(f'{rel} missing common material reference')
    mapper = root / 'MaterialPhaseM1_Definition/MaterialPropertyMapper.cpp'
    if mapper.exists():
        mt = mapper.read_text(encoding='utf-8', errors='replace')
        if mt.count('CommonMaterialDefinition.LoadSynchronous()') < 3:
            errors.append('legacy mapper does not prefer CommonMaterialDefinition in all three conversions')

    bridge_patch = package / 'Patches/material-worldstate-bridge.patch'
    if addon_mode:
        if not bridge_patch.exists():
            errors.append('missing Patches/material-worldstate-bridge.patch')
        else:
            patch_text = bridge_patch.read_text(encoding='utf-8', errors='replace')
            for token in ['ExtensionCellPayloads', 'SaveVersion = 4', 'Version != 3']:
                if token not in patch_text:
                    errors.append(f'WorldState bridge patch missing expected marker: {token}')
    else:
        for rel in ['WorldCore/ChunkState.h','WorldPhaseW6_Persistence/ChunkSerializer.h','WorldPhaseW6_Persistence/ChunkSerializer.cpp','WorldPhaseW6_Persistence/WorldPersistence.cpp']:
            f=root/rel
            if not f.exists() or 'ExtensionCellPayloads' not in f.read_text(encoding='utf-8', errors='replace'):
                errors.append(f'{rel} missing W6 material extension-payload integration')
        wp = root / 'WorldPhaseW6_Persistence/WorldPersistence.cpp'
        if wp.exists():
            wpt = wp.read_text(encoding='utf-8', errors='replace')
            if 'SaveVersion = 4' not in wpt or 'Version != 3 && Version != SaveVersion' not in wpt:
                errors.append('W6 save version 4 / v3 backwards compatibility marker missing')
    wall = root / 'MaterialPhaseM4_Composite/CompositeWallActor.cpp'
    if wall.exists() and 'nullptr : nullptr' in wall.read_text(encoding='utf-8', errors='replace'):
        errors.append('composite wall still contains the all-null material bug')

    result = {
        'target_engine': 'Unreal Engine 5.8 (not UBT/UHT verified)',
        'source_root': 'Source/MyProject2',
        'package_mode': 'addon-overlay' if addon_mode else 'integrated-project',
        'material_folders': DIRS,
        'material_headers': len(headers), 'material_cpp': len(cpps),
        'material_source_files': len(headers) + len(cpps),
        'legacy_definitions_preserved': True,
        'w6_extension_payload_integration': True,
        'static_checks_only': True,
        'errors': errors, 'warnings': warnings,
    }
    manifest = package / 'MANIFEST_MATERIAL.json'
    included = []
    for p in sorted(root.rglob('*')):
        if p.is_file() and any(part in set(DIRS) for part in p.relative_to(root).parts):
            data = p.read_bytes()
            included.append({'path': p.relative_to(package).as_posix(), 'size_bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    result['material_files_manifest'] = included
    manifest.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'Material headers: {len(headers)}; cpp: {len(cpps)}; files: {len(headers)+len(cpps)}')
    print(f'Errors: {len(errors)}; warnings: {len(warnings)}')
    for item in errors: print('ERROR:', item)
    for item in warnings: print('WARNING:', item)
    print(f'Manifest: {manifest}')
    return 1 if errors else 0

if __name__ == '__main__':
    sys.exit(main())
