# Material M1–M6 — Teknik Denetim

## Kaynak çıktısı

Sağlanan metindeki ayrı C++ bloklarından **68 dosya** çıkartıldı: **35 `.h` ve 33 `.cpp`**. Kaynaktaki özet tablosu 70 dosya söylüyor ancak görünen gerçek dosya bloklarının sayısı 68. İstenen tüm gösterilmiş klasör/fazlar içeriliyor; eksik görünen iki dosya uydurulmadı.

## Düzeltmeler

- `EInteractionType` tanımı `MaterialInteractionSubsystem.h` tarafından dahil edildi; etkileşim matrisi ve kural sınıfları için gereken forward declaration/include'lar eklendi.
- UHT'nin plain `USTRUCT` içine `UFUNCTION` yazılmasını kabul etmemesi nedeniyle `FMaterialProperties`, `FMaterialInstanceState` ve `FStructuralLayer` içindeki yardımcı metotlar normal C++ metotları olarak bırakıldı. Alanlar Blueprint yansımasında duruyor; bu metotlar doğrudan Blueprint fonksiyonu olarak çağrılmaz.
- Özel ateş/su/darbe/zaman kuralları artık `bIsEnabled` alanını dikkate alıyor. `PredictReaction` yalnızca hasar pozitifse reaksiyon döndürüyor. Water/Time/Fire süreleri, günlük oranlarla tutarlı olması için saatten güne normalize ediliyor.
- Material matrix artık kurallar dizisini ve tanımlı default kural alanlarını değerlendiriyor; önceki taslakta `Matrix` pratikte hiç kullanılmıyordu.
- `ACompositeWallActor` katmanları BeginPlay sırasında bir defa kurar. Runtime layer component'leri owner'a eklenip register edilir. Hasar hesaplaması ortak etkileşim subsystem'inden geçer; kaynakta ateş hasarı için her zaman `nullptr` materyal gönderilmesi düzeltildi. Kaplama çökmesi iskelete, iskelet çökmesi çatıya yayılır.
- `UMaterialChunkIntegration` artık `nullptr` materyal üzerinde zaman kuralı çağırmıyor. Ortak registry'den materyal çözümlemeye çalışıyor, aksi durumda güvenli ahşap fallback profili kullanıyor.
- `UMaterialPersistenceIntegration` kayıt başlığı/sürümü ve payload sınır denetimleri kullanıyor. World State'de generic sparse `ExtensionCellPayloads` eklendi; W6 serializer bu payload'ları kaydeder ve geri yükler. Save formatı v4'e çıkarıldı ve loader v3 kayıtlarını da extension payload olmadan okuyabilir.
- Legacy üç tanımda isteğe bağlı `CommonMaterialDefinition` soft referansı eklendi. Mapper, referans atanmışsa ortak malzeme profiline geçer; değilse legacy alanlardan profil üretir.
- Test harness'te yalnızca `NewObject != nullptr` veya sabit `true` döndüren kontroller yerine profil, reaksiyon, kompozit katman ve hasar yayılımı davranışlarını test eden kontroller bulunur.

## Önemli sınırlamalar

1. Gerçek UnrealBuildTool / UnrealHeaderTool derlemesi ve PIE testi yapılmadı. Bu nedenle paket "UE 5.8 altında derlenmiş" diye sunulamaz.
2. `Content/Materials` CSV dosyaları gerçek `.uasset` değildir. Material Definition Library ve Interaction Matrix Data Asset'leri Editor'de oluşturulup referansları atanmalıdır.
3. `UMaterialRegistry`'ye material library içeriği otomatik yüklenmez; oyun başlangıcında `LoadAllMaterials` çağrılmalıdır. Matris de world subsystem'e `ConfigureMatrix` ile atanmalıdır.
4. Chunk entegrasyonu `FBiomassCell` alanlarını çevresel yanma/çürüme için kullanır; biyokütlenin `SpeciesID`'si ile malzeme `MaterialID`'si kavramsal olarak aynı değildir. Registry'de species ID eşleşmesi yoksa `Wood` fallback profili kullanılır. Oyunun tam tür/malzeme taksonomisi için açık eşleme tablosu önerilir.
5. Material instance payload kayıt sistemi state'i W6'ya taşır, ancak her etkileşim türü otomatik oluşmaz: `UpdateChunkMaterials` bütçeli/lazy chunk güncelleme döngüsünden çağrılmalıdır. `UMaterialInstanceStateComponent` ve `UMaterialChunkIntegration` aynı Actor için eşzamanlı kaynak state'i yapılırsa iki ayrı state kopyası tutmamak gerekir.
6. Etkileşim damage değerleri oyun tasarımı parametreleridir; fiziksel laboratuvar birimleri değildir. Density dışında çoğu özellik normalize simülasyon skoru olarak değerlendirilmelidir. Özellikle çarpışma, yangın ve sıvı hasarı oyun içi kalibrasyon gerektirir.
7. `MaterialTestHarness::RunAllTests` UE içinde çağrılmak üzere hazırlanmıştır. Kaynakta bulunması, bu harness'in motor içinde yürütüldüğü anlamına gelmez.
8. Eski save v3 verileri yüklenebilir; yeni kayıtlar v4'tür. Material payload'ları olmayan v3 kayıtları yüklenince material extension map'i boş kalır.

## Statik kontrol kapsamı

`Scripts/check_material_source.py` include/Generated-header sırası, proje içi header referansları, USTRUCT yansıma riskleri, legacy bridge alanları ve W6 payload bağını kontrol eder. `Scripts/test_material_math.py` formüllerin referans aritmetik sonuçlarını denetler. Bunlar compiler/UHT veya runtime test değildir.
