# MyProject2.Build.cs — Material modülleri

`Folders` dizisine şu klasörleri ekleyin (birleştirilmiş paket Build.cs dosyasında zaten eklenmiştir):

```csharp
"MaterialCore",
"MaterialPhaseM1_Definition",
"MaterialPhaseM2_Interaction",
"MaterialPhaseM3_Instance",
"MaterialPhaseM4_Composite",
"MaterialPhaseM5_PlasterMetal",
"MaterialPhaseM6_Integration",
```

Bu liste `Source/MyProject2` altındaki göreli klasörlerdir. Add-on kullanımında eski tanım header'larına `CommonMaterialDefinition` soft referansı ekleyen `Scripts/apply_material_legacy_bridge.py` betiğini çalıştırın; W6 chunk payload değişiklikleri için `Patches/material-worldstate-bridge.patch` dosyasını kullanın. Birebir farklı bir World State sürümüne patch uygulamadan önce hedef kaynaklarla karşılaştırma yapın.
