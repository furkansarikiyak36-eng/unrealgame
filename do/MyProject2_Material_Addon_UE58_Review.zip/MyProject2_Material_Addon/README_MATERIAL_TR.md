# MyProject2 — Material & Substance Simulation (M1–M6)

Bu katman; ortak malzeme profili, merkezi etkileşim kuralları, runtime instance state, katmanlı yapı, alçı/kür, metal korozyonu ve chunk-save entegrasyonu sağlar. Mevcut `ULogDefinition`, `UStoneDefinition` ve `UStickDefinition` sınıfları silinmez.

## İçerik

- `MaterialCore`: 12 fiziksel/işlevsel özellik, reaksiyon profilleri, definition doğrulaması ve registry.
- `MaterialPhaseM1_Definition`: materyal kataloğu, legacy definition köprüsü ve doğrulama.
- `MaterialPhaseM2_Interaction`: ateş, su, darbe ve zaman kuralları; dünyaya özel `UMaterialInteractionSubsystem`.
- `MaterialPhaseM3_Instance`: nesne başına nem/sıcaklık/hasar/yanma/çürüme/aşınma state'i.
- `MaterialPhaseM4_Composite`: Foundation/Skeleton/Cladding/Roof/Connector benzeri katmanlar ve çökme zinciri.
- `MaterialPhaseM5_PlasterMetal`: alçı kür süreci ve metal korozyonu.
- `MaterialPhaseM6_Integration`: chunk hücresini güncelleme, material state'i serialize etme, debug HUD ve 9 test için harness.

## Kurulum — birleştirilmiş kaynak paketi

`Source/MyProject2/` ağacını mevcut projenizdeki aynı klasörle birleştirin. Arşivdeki `MyProject2.Build.cs`, mevcut temel klasörlere ek olarak şu 7 include klasörünü içerir:

```text
MaterialCore
MaterialPhaseM1_Definition
MaterialPhaseM2_Interaction
MaterialPhaseM3_Instance
MaterialPhaseM4_Composite
MaterialPhaseM5_PlasterMetal
MaterialPhaseM6_Integration
```

Birleştirilmiş paket `ULogDefinition`, `UStoneDefinition` ve `UStickDefinition` sınıflarına isteğe bağlı `CommonMaterialDefinition` soft reference alanlarını ekler. Bu alanlar var olan property/actor sistemlerini silmez ve boş bırakıldığında legacy alanlardan profil üretmeye devam edilir. Mapper atanmış ortak Data Asset varsa onun `Properties` alanını, yoksa eski tanımdaki değerleri kullanır.

## Kurulum — add-on

Sadece add-on kullanılıyorsa, `Source/MyProject2/Material*` klasörlerini kopyaladıktan sonra `Scripts/apply_material_legacy_bridge.py` betiğini mevcut `Source/MyProject2` üzerinde çalıştırın ve `BUILD_CS_MATERIAL_PATCH_TR.md` içindeki 7 klasörü `MyProject2.Build.cs` dosyasına ekleyin. Add-on içindeki `Patches/material-worldstate-bridge.patch`, sparse chunk payload alanları ve W6 kayıt formatı için önceki World State paketine uygulanacak değişiklikleri içerir.

## Data Asset kurulumu

Editor'de `UPrimaryDataAsset` tabanlı aşağıdaki varlıkları oluşturun:

1. `DA_Material_Stone` — MaterialID `Stone`, MaterialClass `Stone`.
2. `DA_Material_Wood` — MaterialID `Wood`, MaterialClass `Wood`.
3. `DA_Material_Plaster` — MaterialID `Plaster`, MaterialClass `Plaster`.
4. `DA_Material_Soil` — MaterialID `Soil`, MaterialClass `Soil`.
5. `DA_Material_Metal` — MaterialID `Metal`, MaterialClass `Metal`.
6. `DA_MaterialDefinitionLibrary` — bu beş Data Asset'i `MaterialDefinitions` dizisine ekleyin.
7. İsteğe bağlı `DA_MaterialInteractionMatrix` — inline rule'ları veya özel türevleri belirleyin.

`UMaterialRegistry` bir `UGameInstanceSubsystem`'dur; içerikleri otomatik olarak taramaz. Oyun başlangıcında `UMaterialDefinitionLibrary::LoadAllMaterials(Registry)` çağrılmalıdır. World başına etkileşim matrisi atamak için `UMaterialInteractionSubsystem::ConfigureMatrix(...)` kullanın. Materyal Data Asset'leri bu kaynak paketinde gerçek `.uasset` olarak değil, CSV referansı olarak verilir.

## Birleştirme davranışı

`ACompositeWallActor` ilk `BeginPlay` sırasında varsayılan Foundation + Skeleton + Cladding + Roof katmanlarını oluşturur. `UMaterialInteractionSubsystem` boş/no-op tick çalıştırmaz; etkileşimler `ApplyInteraction(...)` ile açıkça tetiklenir. `UMaterialChunkIntegration::UpdateChunkMaterials(...)` chunk hücresindeki biyokütleyi ateş/çürüme kuralına göre günceller ve `FMaterialInstanceState` snapshot'ını `UChunkState::ExtensionCellPayloads` içine yazar. W6 serializer bu sparse payload map'ini de saklar.

## Build

Windows örneği:

```bat
"C:\Program Files\Epic Games\UE_5.8\Engine\Build\BatchFiles\Build.bat" MyProject2Editor Win64 Development -Project="C:\Path\To\MyProject2.uproject"
```

Bu komut belgede örnek olarak verilmiştir; paket üretim ortamında UE 5.8 UBT/UHT çalıştırılmadı. Statik kontroller, motor derlemesi yerine geçmez.
