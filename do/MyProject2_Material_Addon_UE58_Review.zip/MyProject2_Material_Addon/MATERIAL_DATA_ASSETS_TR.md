# Material Data Asset değerleri

Aşağıdaki CSV'ler Editor'de `UMaterialDefinition` Data Asset'lerini kurmak için referans tablolarıdır. Bunlar Unreal `.uasset` dosyaları değildir.

| Asset | MaterialID | Class | Density | Hardness | Compression | Tensile | Brittleness | Flammability | FuelValue | Absorption | WaterDamage | Decay | Workability |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| DA_Material_Stone | Stone | Stone | 2500 | 80 | 90 | 20 | 0.7 | 0.0 | 0 | 0.15 | 0.02 | 0.001 | 0.3 |
| DA_Material_Wood | Wood | Wood | 600 | 30 | 60 | 70 | 0.3 | 0.8 | 15 | 0.4 | 0.3 | 0.02 | 0.9 |
| DA_Material_Plaster | Plaster | Plaster | 1000 | 20 | 30 | 10 | 0.9 | 0.0 | 0 | 0.8 | 0.8 | 0.005 | 0.95 |
| DA_Material_Soil | Soil | Soil | 1500 | 5 | 20 | 5 | 0.1 | 0.0 | 0 | 0.9 | 0.5 | 0.001 | 0.8 |
| DA_Material_Metal | Metal | Metal | 7800 | 90 | 95 | 95 | 0.1 | 0.0 | 0 | 0.0 | 0.05 | 0.0001 | 0.4 |

## Reaksiyon kuralı başlangıç ayarları

- **Fire:** hedef profil yanıcı olmalı; temel tutuşma sıcaklığı 200°C, yanma hızı katsayısı 1.0.
- **Water:** minimum temas nemi 0.1, şişme eşiği 0.5.
- **Impact:** temel eşik 5; çatlak eşiği 0.3 ve parçalanma eşiği 0.7 normalize hasar skoruna göre değerlendirilir.
- **Time:** malzeme çürüme hızı gün tabanlıdır; metal için `WaterDamageRate` korozyon fallback katsayısı olarak kullanılır. Özel `UMetalDefinition` varlığındaki `CorrosionRate` ayrı korozyon bileşenini besler.
