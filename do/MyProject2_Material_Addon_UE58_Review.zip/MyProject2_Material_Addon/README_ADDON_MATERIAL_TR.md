# MyProject2 Material M1–M6 Add-on

Bu arşiv yalnızca yeni `MaterialCore` ve `MaterialPhaseM1_Definition`–`MaterialPhaseM6_Integration` kaynak klasörlerini içerir; mevcut Wood/Stone/Stick/Inventory/Raid/Farming/WorldState klasörlerinin yerine geçmez.

## Uygulama sırası

1. Yedi `Material*` klasörünü hedef `Source/MyProject2/` içine kopyalayın.
2. `Scripts/apply_material_legacy_bridge.py --source-dir "<Project>/Source/MyProject2"` komutunu çalıştırın. Betik, `LogDefinition.h`, `StoneDefinition.h` ve `StickDefinition.h` dosyalarına isteğe bağlı `CommonMaterialDefinition` soft reference alanlarını ekler; tekrar çalıştırılması güvenlidir.
3. `Patches/material-worldstate-bridge.patch` yamasını, bu add-on'un temel aldığı World State kaynak sürümüne uygulayın. Bu değişiklik generic `ExtensionCellPayloads` alanını ve W6 v4 kayıt desteğini ekler; v3 kayıtlar da okunabilir.
4. `BUILD_CS_MATERIAL_PATCH_TR.md` içindeki 7 klasörü `MyProject2.Build.cs` dosyasına ekleyin.
5. Material Data Asset'lerini Editor'de oluşturun ve GameInstance başlangıcında `UMaterialDefinitionLibrary::LoadAllMaterials` çağırın. World interaction subsystem'e `ConfigureMatrix` ile kural matrisi atayın.

Hedef dosyalar temel kaynak paketinden farklıysa patch'i doğrudan uygulamayın; önce değişiklikleri elle birleştirin.

## Statik test

`Scripts/check_material_source.py --project-root "<ProjectRoot>"` birleştirilmiş kaynak ağacını denetler. `Scripts/test_material_math.py` C++/UE testi değildir; formül referans değerlerini Python ile kontrol eder.
