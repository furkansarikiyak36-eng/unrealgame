FAZ 2 - Kesim ve şekillendirme (mekanik 16-32)

Bu zip Wood/ klasörünün TAMAMINI içerir (Faz 1 + Faz 2). Faz 1 dosyalarının üzerine yaz:
WoodTypes.h/.cpp değişti (bLengthGroove, FWoodSlice, kesit boyutları eklendi).

Yeni dosyalar:
- WoodCutLibrary.h/.cpp   : kesim kuralları (saf veri, test edilebilir)
- WoodCutterComponent.h/.cpp : sonucu dünyaya uygular, yeni parça aktörü üretir

Kullanım:
1. Kütük aktörüne WoodPieceComponent + WoodCutterComponent ekle.
2. Kütüğün uzun ekseni X değilse LocalLengthAxis'i ayarla.
3. GetCutLineWorldPositions() ile modül çizgilerini göster, CutAtWorldPoint() ile kes.

Kapsanan mekanikler: 16-23, 24-29 (kurallar + veri), 30, 31, 32.

BİLİNEN SINIR: Görsel yaklaşıktır (ölçek). Yarım silindir kesiti, sivri uç, çentik ve oluk geometrisi
henüz üretilmiyor. WoodCutterComponent::ReshapeVisual olayı bunun için bırakıldı; Faz 2b'de
DynamicMesh (GeometryScript) ile doldurulacak veya CarvableLog'un mevcut kesim kodu buraya bağlanacak.
